/** Automatically generated file. DO NOT MODIFY */
package com.shawn.gpdaccounting;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}